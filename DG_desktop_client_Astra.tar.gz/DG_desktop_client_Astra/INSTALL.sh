#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Установка DataGate клиента для Электронного журнала"
I=`dpkg -s chromium | grep "Status" `
if [ -n "$I" ]
then
   echo "Введите ip-адрес Вашего сервера БД Параграф:"
   read IPADDRESS
   cp -r .DG_journal_icon/ $HOME
   cd $HOME/.DG_journal_icon/
   echo "[Desktop Entry]
         Name=Электронный журнал
         Type=Application
         NoDisplay=false
         Exec=chromium --app=https://$IPADDRESS --window-size=1280,800
         Icon=$HOME/.DG_journal_icon/datagate.png
         Hidden=false
         Terminal=false
         StartupNotify=false" > journal.desktop
   cp journal.desktop $HOME/Desktop
   echo "Установка завершена успешно!"
   exit 0
else
   sudo apt install chromium
   echo "Введите ip-адрес Вашего сервера БД Параграф:" 
   read IPADDRESS
   cp -r .DG_journal_icon/ $HOME
   cd $HOME/.DG_journal_icon/
   echo "[Desktop Entry]
         Name=Электронный журнал
         Type=Application
         NoDisplay=false
         Exec=chromium --app=https://$IPADDRESS --window-size=1280,800
         Icon=$HOME/.DG_journal_icon/datagate.png
         Hidden=false
         Terminal=false
         StartupNotify=false" > journal.desktop
   cp journal.desktop $HOME/Desktop
   echo "Установка завершена успешно!"
   exit 0
fi
exit 0
